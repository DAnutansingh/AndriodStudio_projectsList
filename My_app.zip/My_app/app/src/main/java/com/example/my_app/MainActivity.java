package com.example.my_app;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView view;
    private Button generate;
    private String[] quote={"It is better to be hated for what you are than to be loved for what you are not.",
    "Do one thing every day that scares you.",
    "A journey of a thousand miles begins with a single step.",
    "Eighty percent of success is showing up.",
    "Well done is better than well said."};


@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        view=findViewById(R.id.textView);
        generate=findViewById(R.id.button);
        generate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random random=new Random();
                int index= random.nextInt(quote.length);
                view.setText(quote[index]);
            }
        });
    }
}