package com.example.button;

import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity6 extends AppCompatActivity {

    ImageView imageView;
    ImageButton filterButton;
    boolean isFiltered = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main6);

        imageView = findViewById(R.id.imageView);
        filterButton = findViewById(R.id.filterButton);

        filterButton.setOnClickListener(v -> {
            if (!isFiltered) {
                // Apply grayscale filter
                ColorMatrix matrix = new ColorMatrix();
                matrix.setSaturation(0); // 0 = grayscale

                ColorMatrixColorFilter filter = new ColorMatrixColorFilter(matrix);
                imageView.setColorFilter(filter);
                isFiltered = true;
            } else {
                // Remove filter
                imageView.clearColorFilter();
                isFiltered = false;
            }
        });
    }
}