package com.example.button;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity4 extends AppCompatActivity {

    RadioGroup radioGroup;
    Button selectButton;
    Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main4);

        radioGroup = findViewById(R.id.radioGroup);
        selectButton = findViewById(R.id.selectButton);
        nextButton = findViewById(R.id.button2);

        selectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int selectedId = radioGroup.getCheckedRadioButtonId();

                if (selectedId != -1) {
                    RadioButton selectedRadio = findViewById(selectedId);
                    String selectedText = selectedRadio.getText().toString();
                    Toast.makeText(MainActivity4.this, "Selected: " + selectedText, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity4.this, "No option selected", Toast.LENGTH_SHORT).show();
                }
            }
        });

        nextButton.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity4.this, MainActivity5.class);
            startActivity(intent);
        });
    }
}