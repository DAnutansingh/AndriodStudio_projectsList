package com.example.calculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

class mainActivity extends AppCompatActivity {
    EditText enternumber;
    TextView result;
    Button b1, b2, b0, b3, b4, b5, b6, b7, b8, b9, badd, bsub, bmul, beql;
    String currentInput = "";
    String operator = "";
    double firstNumber, secondNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        enternumber = findViewById(R.id.editTextText3);
        result = findViewById(R.id.textView3);

        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);
        b6 = findViewById(R.id.b6);
        b7 = findViewById(R.id.b7);
        b8 = findViewById(R.id.b8);
        b9 = findViewById(R.id.b9);
        b0 = findViewById(R.id.b0);

        badd = findViewById(R.id.badd);
        bsub = findViewById(R.id.bsub);
        bmul = findViewById(R.id.bmul);
        beql = findViewById(R.id.beql);

        View.OnClickListener numberClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                currentInput += button.getText().toString();
                enternumber.setText(currentInput);
            }
        };
        b1.setOnClickListener(numberClickListener);
        b2.setOnClickListener(numberClickListener);
        b3.setOnClickListener(numberClickListener);
        b4.setOnClickListener(numberClickListener);
        b5.setOnClickListener(numberClickListener);
        b6.setOnClickListener(numberClickListener);
        b7.setOnClickListener(numberClickListener);
        b8.setOnClickListener(numberClickListener);
        b9.setOnClickListener(numberClickListener);
        b0.setOnClickListener(numberClickListener);
        View.OnClickListener operatorClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button button = (Button) v;
                if (!currentInput.equals("")) {
                    firstNumber = Double.parseDouble(currentInput);
                    operator = button.getText().toString();
                    currentInput = "";
                    enternumber.setText("");
                }
            }
        };
        badd.setOnClickListener(operatorClickListener);
        bsub.setOnClickListener(operatorClickListener);
        bmul.setOnClickListener(operatorClickListener);

        beql.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!currentInput.equals("")) {
                    secondNumber = Double.parseDouble(currentInput);
                    double output = 0;
                    switch (operator) {
                        case "+":
                            output = firstNumber + secondNumber;
                            break;
                        case "-":
                            output = firstNumber - secondNumber;
                            break;
                        case "*":
                            output = firstNumber * secondNumber;
                            break;
                    }
                    result.setText("Result: " + output);
                    currentInput = "";
                }
            }
        });

    }
}
