package com.example.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private EditText num1;
    private EditText num2;
    private TextView result;
    private Button add;
    private Button sub;
    private Button mul;
    private Button div;

    private Button back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        num1 = findViewById(R.id.editTextText);
        num2 = findViewById(R.id.editTextText2);
        add = findViewById(R.id.button);
        sub = findViewById(R.id.button2);
        mul = findViewById(R.id.button3);
        div = findViewById(R.id.button4);
        back=findViewById(R.id.button5);
        result = findViewById(R.id.textView7);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=num1.getText().toString();
                String b=num2.getText().toString();
                double num_1=Double.parseDouble(a);
                double num_2=Double.parseDouble(b);
                double sum=num_1+num_2;
                result.setText(sum+"");
            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=num1.getText().toString();
                String b=num2.getText().toString();
                double num_1=Double.parseDouble(a);
                double num_2=Double.parseDouble(b);
                double substract=num_1-num_2;
                result.setText(substract+"");
            }
        });

        mul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=num1.getText().toString();
                String b=num2.getText().toString();
                double num_1=Double.parseDouble(a);
                double num_2=Double.parseDouble(b);
                double multiply=num_1*num_2;
                result.setText(multiply+"");
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String a=num1.getText().toString();
                String b=num2.getText().toString();
                double num_1=Double.parseDouble(a);
                double num_2=Double.parseDouble(b);
                double divide=num_1/num_2;
                result.setText(divide+"");
            }
        });
    }
}