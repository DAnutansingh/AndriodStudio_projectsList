package com.example.relative_layout;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private ImageView profileImage;
    private TextView nameText;
    private TextView descText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ImageView profileImage = findViewById(R.id.profileImage);
        TextView nameText = findViewById(R.id.nameText);
        TextView descText = findViewById(R.id.descText);

        nameText.setText("Jane Doe");
        descText.setText("Android Engineer");
        profileImage.setImageResource(R.drawable.pic1);


    }
}